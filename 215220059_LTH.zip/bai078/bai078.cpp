#include<iostream>
#include<math.h>
using namespace std;
void nhap(int&, int&);
int tong(int, int);

int main()
{
	int n, x, s;
	nhap(n, x);
	s = tong(n, x);
	cout << "s = " << s;
	return 0;
}

void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}

int tong(int n, int x)
{
	int s = 1, a = 1;
	for (int i = 1; i <= n; i++)
	{
		a = a * x;
		s = s + a;
	}
	return s;
}