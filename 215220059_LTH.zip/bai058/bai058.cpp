#include<iostream>
using namespace std;
int tong(int);
int main() {
	int n, s;
	cout << "nhap n = ";
	cin >> n;
	s = tong(n);
	cout << "s=" << s;
	return 0;
}

int tong(int n)
{
	int s = 0;
	while (n != 0)
	{
		int dv = n % 10;
		s = s + dv;
		n = n / 10;
	}
	return s;
}