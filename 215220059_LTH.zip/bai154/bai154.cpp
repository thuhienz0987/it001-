#include<iostream>
using namespace std;
void daygt(int);

int main()
{
	int n;
	cout << "nhap n = "; cin >> n;
	daygt(n);
	return 0;
}

void daygt(int n)
{
	int a = n;
	for (int i = 2; i <= n; i++)
	{
		if (a % 2 == 0) a = a / 2;
		else a = 3 * a + 1;
		cout <<a << " ";
	}
}