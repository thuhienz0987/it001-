#include<iostream>
#include<math.h>
using namespace std;
float tong(int, int);
void nhap(int&, int&);

int main()
{
	float s;
	int n, x;
	nhap(n, x);
	s = tong(n, x);
	cout << "e = " << s;
	return 0;
}

float tong(int n, int x)
{
	float e = 1, s = 1, a = 1, b = 1;
	for (int i = 1; e >= pow(10, -6); i++)
	{
		b = b * x;
		a = a * i;
		e = (float)b / a;
		s = s + e;
	}
	return s;
}

void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}