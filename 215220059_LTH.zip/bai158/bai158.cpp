
#include<iostream>
using namespace std;
int dem(int);

int main()
{
	int n,soluong;
	cout << "nhap n = "; cin >> n;
	soluong = dem(n);
	cout << "so luong chu so lon nhat la : " << soluong;
	return 0;
}


int dem(int n)
{
	int max = 0, t, dv,dem=0;
	t = n;
	while (t != 0)
	{
		dv = t % 10;
		if (dv > max)
		{
			max = dv;
			dem = 0;
		}
		if (dv == max) dem++;
		t = t / 10;
	}
	return dem;
}