#include<iostream>
using namespace std;
int sohanga(int);
int sohangb(int);
void nhap(int&, int&, int&);

int main()
{
	int a, b, n;
	nhap(a, b, n);
	a = sohanga(n);
	b = sohangb(n);
	cout << "a" << n << " = " << a << endl;
	cout << "b" << n << " = " << b;
	return 0;
}

int  sohanga(int n)
{
	int at = 1, bt = 1;
	for (int i = 2; i <= n; i++)
	{
		int a = 3 * bt + 2 * at;
		int b = at + 3 * bt;
		at = a;
		bt = b;
	}
	return at;
}

int  sohangb(int n)
{
	int at = 2, bt = 1;
	for (int i = 2; i <= n; i++)
	{
		int a = at * at + 2 * bt * bt;
		int b = 2 * at * bt;
		at = a;
		bt = b;
	}
	return bt;
}

void nhap(int& a, int& b, int& n)
{
	cout << " nhap a = "; cin >> a;
	cout << " nhap b = "; cin >> b;
	cout << "nhap n = "; cin >> n;
}