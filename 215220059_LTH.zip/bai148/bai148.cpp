#include<iostream>
using namespace std;
int chanle(int);

int main()
{
	int n;
	cout << "nhap n = "; cin >> n;
	if (chanle(n) == 1) cout << n << " co toan chu so chan";
	else cout << n << " khong toan chu so chan";
	return 0;

}

int chanle(int n)
{
	int b, flag = 1;
	for (int a = n; a != 0; a = a / 10)
	{
		b = a % 10;
		if (b % 2 != 0) flag = 0;
	}
	return flag;
}