#include<iostream>
using namespace std;
int tim(int);

int  main() 
{
	int k = 0, n;
	cout << "nhap n = "; cin >> n;
	k = tim(n);
	cout << "k = " << k;
	return 0;
}

int tim(int n)
{
	int k = 0;
	for (int s = 0; s < n; s = s + k)
	{
		k++;
	}
	k = k - 1;
	return k;
}