
#include<iostream>
using namespace std;
int dem(int);

int main()
{
	int n, soluong;
	cout << "nhap n = "; cin >> n;
	soluong = dem(n);
	cout << "so luong chu so lon nhat la : " << soluong;
	return 0;
}


int dem(int n)
{
	int min=9, t, dv, dem = 0;
	t = n;
	while (t != 0)
	{
		dv = t % 10;
		if (dv<min)
		{
			min = dv;
			dem = 0;
		}
		if (dv == min) dem++;
		t = t / 10;
	}
	return dem;
}