#include<iostream>
using namespace std;
int dem(int);

int main()
{
	int n, s;
	cout << "nhap n: ";
	cin >> n;
	s = dem(n);
	cout << "so luong cac uoc bang " << s;
	return 0;
}

int dem(int n)
{
	int dem = 0;
	for (int i = 1; i <= n; i++)
	{
		if (n % i == 0) dem++;
	}
	return dem;
}
