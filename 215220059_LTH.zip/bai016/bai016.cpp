#include<iostream>
using namespace std;
float tich(float);

int main()
{
	float x, x9;
	cout << "Nhap x= ";
	cin >> x;
	x9 = tich(x);
	cout << "gia tri x9 la: " << x9;
	return 0;
}

float tich(float x)
{
	float x2 = x * x;
	float x4 = x2 * x2;
	float x8 = x4 * x4;
	float x9 = x8 * x;
	return x9;

}