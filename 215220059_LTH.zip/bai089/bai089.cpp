#include<iostream>
#include<math.h>
using namespace std;
void nhap(int& n, int& x);
float tong(int, int);


int main()
{
	int n, x;
	float s;
	nhap(n, x);
	s = tong(n, x);
	cout << "s=" << s;
	return 0;
}

void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}

float tong(int n, int x)
{
	int a = 0, dau = -1;
	float s = 0;
	for (int i = 1; i <= n; i++)
	{
		a = a + i;
		s = s + dau * (float)pow(x, i) / a;
		dau = -dau;

	}
	return s;
}