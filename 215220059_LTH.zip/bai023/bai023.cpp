#include<iostream>
using namespace std;
int hc(int);
int main() 
{
	int n,hangchuc;
	cout << "Nhap so nguyen duong n: ";
	cin >> n;
	hangchuc = hc(n);
	cout << "chu so hang chuc so nguyen duong n la: " << hangchuc;
	return 0;
}

int hc(int n)
{
	int hc = (n / 10) % 10;
	return hc;
}