#include<iostream>
using namespace std;
double tich(double);

int main()
{
	double x, x64;
	cout << "Nhap x= ";
	cin >> x;
	x64 = tich(x);
	cout << "gia tri x64 la: " << x64;
	return 0;
}

double tich(double x)
{
	float t = pow(x, 2);
	for (int i = 0; i < 5; i++)
	{
		t = pow(t, 2);
	}
	return t;

}