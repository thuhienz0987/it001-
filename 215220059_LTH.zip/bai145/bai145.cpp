#include<iostream>
using namespace std;
int chinhphuong(int);

int main()
{
	int n;
	cout << "nhap n = "; cin >> n;
	if (chinhphuong(n) == 0) cout << n << " la so chinh phuong";
	else cout << n << " khong la so chinh phuong";
	return 0;

}

int chinhphuong(int n)
{
	int flag = 1;
	for (int i = 0; i <= n; i++)
	{
		if (i* i == n) flag = 0;
	}
	return flag;
}