#include<iostream>
using namespace std;
void nhap(int&, int&, int&, int&, int&, int&,int&,int&);
float dientich(int, int, int, int,int,int);

int main()
{
	int xa, ya, xb, yb, xc, yc, xm, ym;
	float s, s1, s2, s3;
	nhap(xa, ya, xb, yb, xc, yc,xm,ym);
	s=dientich(xa, ya, xb, yb, xc, yc);
	s1 = dientich(xm, ym, xb, yb, xc, yc);
	s2 = dientich(xa, ya, xm, ym, xc, yc);
	s3= dientich(xa, ya, xb, yb, xm, ym);
	if (s == s1 + s2 + s3) cout << "thuoc tam giac";
	else cout << "khong thuoc tam giac";
	return 0;
}

void nhap(int& xa, int& ya, int& xb, int& yb, int& xc, int& yc,int& xm,int& ym)

{
	cout << "nhap toa do diem A:\n";
	cout << "xa = "; cin >> xa;
	cout << "ya = "; cin >> ya;
	cout << "nhap toa do diem B:\n";
	cout << "xb = "; cin >> xb;
	cout << "yb = "; cin >> yb;
	cout << "nhap toa do diem C:\n";
	cout << "xc = "; cin >> xc;
	cout << "yc = "; cin >> yc;
	cout << "nhap toa do diem M:\n";
	cout << "xm = "; cin >> xm;
	cout << "ym = "; cin >> ym;
}
float dientich(int xa, int ya, int xb, int yb,int xc,int yc)
{
	float s = (float)(xa * yb + xb * yc + xc * ya - xb * ya - xc * yb - xa * yc) / 2;
	return s;
}
