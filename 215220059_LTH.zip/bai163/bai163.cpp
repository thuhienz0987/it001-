#include<iostream>
using namespace std;
int uocle(int);

int main() {
	int n, max;
	cout << "nhap n = "; cin >> n;
	max = uocle(n);
	cout << "uoc le lon nhat la : " << max;
	return 0;
}

int uocle(int n)
{
	int max;
	for (int i = 1; i <= n; i = i + 2)
	{
		if (n % i == 0) max = i;
	}
	return max;
}