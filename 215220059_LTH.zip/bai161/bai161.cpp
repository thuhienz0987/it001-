#include<iostream>
using namespace std;
int kt(int);

int main() 
{
	int n, flag;
	cout << "nhap n = "; cin >> n;
	flag = kt(n);
	if (flag == 1) cout << "sai";
	else cout << "dung";
	return 0;
}

int kt(int n)
{
	int flag = 1, lc, dv;
	while (n != 0)
	{
		lc = n % 10;
		dv = n % 100;
		if (lc < dv) flag = 0;
		n = n / 10;
	}
	return flag;
}