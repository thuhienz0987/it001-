#include<iostream>
#include<math.h>
using namespace std;
int sohang(int);

int main()
{
	int n, a;
	cout << "nhap n = "; cin >> n;
	a = sohang(n);
	cout << "a" << n << " = " << a;
	return 0;
}

int sohang(int n)
{
	int a = 2;
	for (int i = 2; i <= n; i++)
	{
		int at = a + 2 * i + 1;
		a = at;
	}
	return a;
}