#include<iostream>
using namespace std;
int mu(int);
int tong(int);
void nhap(int&, int&);

int main()
{
	int n, s,x;
	nhap(n, x);
	s = tong(n);
	cout << "s = " << s;
	return 0;
}

int mu(int x)
{
	int g = 1;
	for (int i = 1; i <= x; i++)
		g = g * x;
	return g;
}

int tong(int n)
{
	int s = 0;
	for (int i = 1; i <= n; i++)
		s = s + mu(i);
	return s;
}

void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}