#include<iostream>
using namespace std;
void nhap(int&, int&);
int triso(int);

int main()
{
	int a, b;
	nhap(a, b);
	a = triso(a);
	b = triso(b);
	cout << "a = " << a << endl;
	cout << "b = " << b;
	return 0;
}

void nhap(int& a, int& b)
{
	cout << " nhap a = "; cin >> a;
	cout << " nhap b = "; cin >> b;
}

int triso(int a)
{
	if (a < 0) a = -a;
	return a;
}