#include<iostream>
using namespace std;
int kiemtra(int);

int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;

	if (kiemtra(n) == 1) cout << "ton tai chu so le";
	else cout << "khong ton tai chu so le";
	return 0;
}

int kiemtra(int n)
{
	int flag = 0;
	while (n != 0)
	{
		int i = n % 10;
		if (i % 2 !=0) flag = 1;
		n = n / 10;
	}
	return flag;

}