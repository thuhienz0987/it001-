#include<iostream>
using namespace std;
int dem(int);

int main()
{
	int n, d;
	cout << "nhap n = ";
	cin >> n;
	d = dem(n);
	cout << "so luong chu so la " << d;
	return 0;
}

int dem(int n)
{
	int dem = 0;
	while (n != 0)
	{
		dem++;
		n = n / 10;
	}
	return dem;
}