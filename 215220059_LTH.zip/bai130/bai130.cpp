#include<iostream>
using namespace std;
void nhap(int&, int&, int&);
void dieukien(int , int , int );

int main()
{
	int x, y, z;
	nhap(x, y, z);
	dieukien(x, y, z);
	return 0;
}

void nhap(int& x, int& y, int& z)
{
	cout << " nhap x = "; cin >> x;
	cout << " nhap y = "; cin >> y;
	cout << "nhap z = "; cin >> z;
}

void dieukien(int x, int y, int z)
{
	if ((x + y) >= z && (x + z) >= y && (z + y) >= x) cout << "ton tai mot tam giac tao tu x y z";
	else cout << "khong ton tai tam giac tao tu x y z";
}