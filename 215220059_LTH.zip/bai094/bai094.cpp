#include<iostream>
#include<math.h>
using namespace std;
float can(int);

int main()
{
	int   n;
	float s;
	cout << "nhap n = "; cin >> n;
	s = can(n);
	cout << "s = " << s;
	return 0;
}

float can(int n)
{
	float s = 0;
	for (int i = 1; i <= n; i++)
		s = sqrt(i + s);
	return s;
}