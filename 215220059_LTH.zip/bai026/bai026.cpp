#include<iostream>
using namespace std;
void nhap(int&, int&);
void hoandoi(int&, int&);
int main()
{
	int a, b;
	nhap(a, b);
	hoandoi(a, b);
	cout << "so a va b sau hoan doi la a=" << a << " b=" << b;

	return 0;
}

void nhap(int& a, int& b)
{
	cout << "nhap hai so a va b: \n";
	cout << "a= ";
	cin >> a;
	cout << "b= ";
	cin >> b;
}

void hoandoi(int& a, int& b)
{
	a = a + b;
	b = a - b;
	a = a - b;
}
