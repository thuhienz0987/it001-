#include<iostream>
using namespace std;
int tich(int);

int main()
{
	int n, s;
	cout << "nhap n: ";
	cin >> n;
	s = tich(n);
	cout << "tich cac uoc le bang " << s;
	return 0;
}

int tich(int n)
{
	int t = 1;
	for (int i = 1; i <= n; i=i+2)
	{
		if (n % i == 0 ) t=t*i;
	}
	return t;
}