#include<iostream>;
using namespace std;
float thetich(float);
int main() 
{
	int r;
	cout << "Nhap ban kinh hinh cau r= ";
	cin >> r;
	float V = 4 / 3 * 3.14 * r * r * r;
	cout << "The tich hinh cau ban kinh " << r << " la: " << thetich(r);
	return 0;
}

float thetich(float r)
{
	float V = 4 / 3 * 3.14 * r * r * r;
	return V;
}