#include<iostream>
using namespace std;
void nhap(int&, int&);
void tangdan(int, int);

int main()
{
	int  a, b;
	nhap(a, b);
	tangdan(a, b);
	return 0;
}

void nhap(int& a, int& b)
{
	cout << " nhap a = "; cin >> a;
	cout << " nhap b = "; cin >> b;
}

void tangdan(int a, int b)
{
	int max = 0;
	if (a < b)  cout << a << " " << b;
	else cout << b << " " << a;
}