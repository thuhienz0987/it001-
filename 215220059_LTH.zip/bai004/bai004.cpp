#include<iostream>
using namespace std;
float dientichxq(float);
int main()  
{
	int r;
	cout << "Nhap ban kinh hinh tron r =  ";
	cin >> r;
	cout << "Dien tich xung quanh hinh tron ban kinh " << r << " la: " << dientichxq(r);
	return 0;
}

float dientichxq(float r)
{
	float s = 4 * 3.14 * r * r;
	return s;

}