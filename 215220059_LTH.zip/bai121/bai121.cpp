#include<iostream>
#include<math.h>
using namespace std;
int sohang(int);

int main()
{
	int n,f;
	cout << "nhap n = "; cin >> n;
	f = sohang(n);
	cout << "f" << n << " = " << f;
	return 0;
}

int sohang(int n)
{
    int ft=1,ftt=1;
	for (int i = 2; i <= n; i++)
	{
		int f = ft + ftt;
		ftt = ft;
		ft = f;
	}
	return ft;
}