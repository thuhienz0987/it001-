#include<iostream>
using namespace std;
int lk(int);
void xuat(int);

int main()
{
	int n;
	cout << "nhap n = "; cin >> n;
	xuat(n);
	return 0;
}

int lk(int n)
{
	int a = 1;
	for (int i = 1; i <= n; i++)
		a = a *i;
	return a;
}

void xuat(int n)
{
	for (int i = 1; i <= n; i++)
		cout << lk(i) << " ";
}