#include<iostream>
#include<math.h>
using namespace std;
void nhap(int&, int&);
float tong(int, int);

int main()
{
	int n, x;
	float s;
	nhap(n, x);
	s = tong(n, x);
	cout << "s = " << s;
	return 0;
}

void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}

float tong(int n, int x)
{
	float s = 0;
	int a = 1;
	for (int i = 0; i <= n; i++)
	{
		a = a * (x + i);
		s = s +(float)1/ a;
	}
	return s;
}