#include<iostream>
using namespace std;
int max(int);
int main() {
	int n, lonnhat;
	cout << "nhap n = ";
	cin >> n;
	lonnhat = max(n);
	cout << "t = " << lonnhat;
	return 0;
}

int max(int n)
{
	int max = 0;
	while (n != 0)
	{
		int i = n % 10;
		if (i > max) max = i;
		n = n / 10;
	}
	return max;
}