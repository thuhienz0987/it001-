#include<iostream>
using namespace std;
int songuyento(int);

int main()
{
	int n;
	cout << "nhap n = "; cin >> n;
	if (songuyento(n) == 0) cout << n << " la so nguyen to";
	else cout << n << " khong la so nguyen to";
	return 0;

}

int songuyento(int n)
{
	int flag = 1;
	for (int i = 2; i <= n; i++)
	{
		if (n % i == 0) flag = 0;
	}
	return flag;
}