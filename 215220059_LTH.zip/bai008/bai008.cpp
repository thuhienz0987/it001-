#include<iostream>
#include<math.h>
using namespace std;
void nhap(float&, float&);
float chuvi(float, float);

int main() 
{
	float n, r, C;
	nhap(n, r);
	C = chuvi(n, r);
	cout << "Chu vi da giac deu la: " << C;
	return 0;
}

void nhap(float& n, float& r)
{
	cout << "Nhap so canh cua da giac n= ";
	cin >> n;
	cout << "Nhap ban kinh duong tron r= ";
	cin >>r;
}

float chuvi(float n, float r)
{
	float C = 2 * 3.14 * r * sin(3.14 / n);
	return C;
}
