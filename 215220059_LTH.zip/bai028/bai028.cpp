#include<iostream>
using namespace std;
int tong(int);

int main() {
	int n, kq;
	cout << "nhap n: ";
	cin >> n;
	kq = tong(n);
	cout << "tong bang s = " << kq;
	return 0;
}

int tong(int n)
{
	int s = 0;
	for (int i = 1; i <= n; i++)
		s = s + i * i;
	return s;
}