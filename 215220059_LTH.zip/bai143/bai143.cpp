#include<iostream>
using namespace std;
void sohoanthien(int);

int main()
{
	int n, a;
	cout << "nhap n = "; cin >> n;
	sohoanthien(n);
	return 0;
}

void sohoanthien(int n)
{
	int a, b = 0,s=0;
	for (int i=1;i<n;i++)
	{
		if (n % i == 0) s = s + i;
	}
	if (s == n) cout << n << " la so hoan thien";
	else cout << n << " khong la so hoan thien";
}
/*
#include<iostream>
using namespace std;
void sohoanthien(int);

int main()
{
	int n, a,b;
	cin >> a >> b;
	for (int i = a; i <= b; i++)
	{
		sohoanthien(i);
	}
	return 0;
}

void sohoanthien(int n)
{
	int a, b = 0, s = 0;
	for (int i = 1; i < n; i++)
	{
		if (n % i == 0) s = s + i;
	}
	if (s == n) cout << n << " ";
}*/