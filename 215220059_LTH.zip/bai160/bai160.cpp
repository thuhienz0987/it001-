#include<iostream>
using namespace std;
int soluong(int);
int daonguoc(int);

int main()
{
	int n, dem;
	cout << "nhap n = "; cin >> n;
	dem = soluong(n);
	cout << "so luong bang : " << dem;
	return 0;
}

int soluong(int n)
{
	int dem = 0, t = n;
	int a = daonguoc(n) % 10;
	while (t != 0)
	{
		int b = t % 10;
		if (b == a) dem++;
		t = t / 10;
	}
	return dem;
}

int daonguoc(int n)
{
	int a, b = 0;
	for (int c = n; c != 0; c = c / 10)
	{
		a = c % 10;
		b = b * 10 + a;
	}
	return b;
}