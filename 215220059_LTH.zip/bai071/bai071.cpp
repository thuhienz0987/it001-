
#include<iostream>
#include<math.h>
using namespace std;
int mu(int, int);
int tong(int, int);
void nhap(int&, int&);

int main()
{
	int n, s, x;
	nhap(n, x);
	s = tong(n, x);
	cout << "s = " << s;
	return 0;
}

int mu(int n, int x)
{
	int g = x;
	for (int i = 1; i <= n; i++)
		g = g * x * x ;
	return g;
}

int tong(int n, int x)
{
	int s = 0;
	for (int i = 1; i <= n; i++)
		s = s + mu(i, x);
	return s;
}

void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}