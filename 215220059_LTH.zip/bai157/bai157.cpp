#include<iostream>
using namespace std;
float lk(int);
void xuat(int);

int main()
{
	int n;
	cout << "nhap n = "; cin >> n;
	xuat(n);
	return 0;
}

float lk(int n)
{
	float a = 0;
	for (int i = 1; i <= n; i++)
		a = a + (float)1/i;
	return a;
}

void xuat(int n)
{
	for (int i = 1; i <= n; i++)
		cout << lk(i) << " ";
}