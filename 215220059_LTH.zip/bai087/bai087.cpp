#include<iostream>
using namespace std;
void nhap(int&, int&);
int tong(int, int);
int mu(int, int);

int main() {
	int x, n, s;
	nhap(n, x);
	s = tong(n, x);
	cout << "s = " << s;
	return 0;
}


void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}

int tong(int n, int x)
{
	int s = x, dau = -1;
	for (int i = 1; i <= n; i++)
	{
		s = s + dau * mu(i, x);
		dau = -dau;
	}
	return s;
}

int mu(int n, int x)
{
	float a = x;
	for (int i = 1; i <= n; i++)
		a = a * x * x;
	return a;
}