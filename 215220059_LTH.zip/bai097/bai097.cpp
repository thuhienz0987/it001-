#include<iostream>
using namespace std;
float can(int);
void nhap(int& n, int& x);

int main()
{
	int   n,x;
	float s;
	nhap(n, x);
	s = can(n);
	cout << "s = " << s;
	return 0;
}

void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}


float can(int n, int x)
{
	float s = 0;
	int a = 1;
	for (int i = 1; i <= n; i++)
	{
		a = a * x;
	    s = sqrt(a+ s);
	}
		return s;
}
//sai