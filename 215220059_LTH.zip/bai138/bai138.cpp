#include<iostream>
#include<math.h>
using namespace std;
void dk(int&);

int main()
{
	int x;
	cout << "nhap x = "; cin >> x;
	dk(x);
	return 0;
}

void dk(int& x)
{
	int f;
	if (x >= 1) f = 2 * pow(x, 3) + 5 * x * x - 8 * x + 3;
	else
	{
		if (x < 0) f = -2 * pow(x, 3) + 6 * x + 9;
		else f = 5 * x - 7;
	}
	cout << "gia tri ham so f" << x << " la: " << f;
}