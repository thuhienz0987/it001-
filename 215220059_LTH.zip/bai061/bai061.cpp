#include<iostream>
using namespace std;
int dem(int);
int main() {
	int n, d;
	cout << "nhap n = ";
	cin >> n;
	d = dem(n);
	cout << "so luong chu so le cua so nguyen la " << d;
	return 0;
}

int dem(int n)
{
	int dem = 0;
	while (n != 0)
	{
		int i = n % 10;
		if (i % 2 == 1) dem++;
		n = n / 10;
	}
	return dem;
}