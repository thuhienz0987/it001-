#include<iostream>
using namespace std;
int tong(int);
int main() {
	int n, s;
	cout << "nhap n = ";
	cin >> n;
	s = tong(n);
	cout << "tong cac chu so chan la : " << s;
	return 0;
}

int tong(int n)
{
	int s = 0;
	while (n != 0)
	{
		int i = n % 10;
		if (i % 2 == 0) s = s + i;
		n = n / 10;
	}
	return s;
}