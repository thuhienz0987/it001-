#include<iostream>
using namespace std;
float dientich(float);

int main() 
{
	int r;
	cout << "Nhap ban kinh duong tron: \n";
	cout << "r = ";
	cin >> r;
	cout << "Dien tich hinh tron ban kinh " << r << " la :" << dientich(r);
	return 0;
}

float dientich(float r)
{
	float s = r * 3.14 * r;
	return s;
}