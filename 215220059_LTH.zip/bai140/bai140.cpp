#include<iostream>
using namespace std;
void nhap(float&, float&,float&);
void ptbac2(float, float,float);

int main()
{
	float a, b,c;
	nhap(a, b,c);
	ptbac2(a, b,c);
	return 0;
}

void nhap(float& a, float& b,float& c)
{
	cout << "nhap a va b :\n";
	cout << "a = "; cin >> a;
	cout << "b = "; cin >> b;
	cout << "c = "; cin >> c;
}

void ptbac2(float a, float b,float c)
{
	float d = b * b - 4 * a * c;
	if (d < 0)cout << "phuong trinh vo nghiem";
	else {
		if (d == 0) cout << "phuong trinh co nghiem kep x = " << (float)-b / 2 * a;
		else {
			float x1 = (-b - sqrt(d)) / (2 * a);
			float x2 = (-b + sqrt(d)) / (2 * a);
			cout << "phuong trinh co hai nghiem x1 = " << x1 << " va x2 = " << x2;

		}
	}
}