#include<iostream>
#include<math.h>
using namespace std;
int sohang(int);

int main()
{
	int n, a;
	cout << "nhap n = "; cin >> n;
	a = sohang(n);
	cout << "a" << n << " = " << a;
	return 0;
}

int sohang(int n)
{
	int a = 2, t = 3,h=7;
	for (int i = 2; i <= n; i++)
	{
		t = t * 3;
		h = h * 7;
		int at = 5 * a + 2 * t - 6 * h + 12;
		a = at;
	}
	return a;
}