#include<iostream>
using namespace std;
void dk(int&);

int main()
{
	int x;
	cout << "nhap x = "; cin >> x;
	dk(x);
	return 0;
}

void dk(int& x)
{
	int f;
	if (x >= 5) f = 2 * x * x + 5 * x + 9;
	else f = -2 * x * x + 4 * x - 9;
	cout << "gia tri ham so f" << x << " la: " << f;
}