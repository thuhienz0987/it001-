#include<iostream>
using namespace std;
void nhap(int&, int&);
int uocchung(int, int);

int main() 
{
	int max,a,b;
	nhap(a, b);
	max = uocchung(a, b);
	cout << "uoc chung lon nhat la: " << max;
	return 0;
}

void nhap(int& a, int& b)
{
	cout << " nhap a = "; cin >> a;
	cout << " nhap b = "; cin >> b;
}

int uocchung(int a, int b)
{
	while (a != b)
	{
		if (a < b) b = b - a;
		a = a - b;
	}
	return a;
}