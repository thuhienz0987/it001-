#include<iostream>
using namespace std;
void nhap(int&, int&, int&, int&,int&,int&);
float khoangcach(int, int, int, int);
void dieukien(float,float,float);

int main()
{
	int xa, ya, xb, yb, xc, yc;
	float a, b, c;
	nhap(xa, ya, xb, yb, xc, yc);
	a = khoangcach(xa, ya,xb,yb);
	b = khoangcach(xb, yb,xc,yc);
	c = khoangcach(xc, yc,xa,ya);
	dieukien(a, b, c);
	return 0;
}

void nhap(int& xa, int& ya, int& xb, int& yb, int& xc, int& yc)

{
	cout << "nhap toa do diem A:\n";
	cout << "xa = "; cin >> xa;
	cout << "ya = "; cin >> ya;
	cout << "nhap toa do diem B:\n";
	cout << "xb = "; cin >> xb;
	cout << "yb = "; cin >> yb;
	cout << "nhap toa do diem C:\n";
	cout << "xc = "; cin >> xc;
	cout << "yc = "; cin >> yc;
}
float khoangcach(int xa, int ya,int xb,int yb)
{
	float a = (float)sqrt((xa - xb) * (xa - xb) + (ya - yb) * (ya - yb));
	return a;
}
void dieukien(float a, float b, float c)
{
	if ((a + b) >= c && (a + c) >= b && (c + b) >= a) cout << "la ba dinh cua tam giac";
	else cout << "khong la ba dinh cua tam giac";
}