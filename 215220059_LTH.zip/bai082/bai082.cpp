#include<iostream>
#include<math.h>
using namespace std;
float tong(int,int);
float mu(int, int);
void nhap(int&, int&);

int main()
{
	int n, x;
	float s;
	nhap(n, x);
	s = tong(n, x);
	cout << "s = " << s;
	return 0;
}

float mu(int n,int x)
{
	float a = 1;
	for (int i = 1; i <= n; i++)
		a = a * sin(x);
	return a;
}

float tong(int n,int x)
{
	float s = 0;
	for (int i = 1; i <= n; i++)
		s = s + mu(i, x);
	return s;
}

void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}