#include<iostream>
using namespace std;
float tong(int);

int main() {
	int n;
	float s;
	cout << "nhap n: ";
	cin >> n;
	s = tong(n);
	cout << "tong bang s= " << s;
	return 0;
}

float tong(int n)
{
	float s = 0;
	for (int i = 1; i <= n; i++)
		s += (float)1 / (i * (i + 1));
	return s;
}
