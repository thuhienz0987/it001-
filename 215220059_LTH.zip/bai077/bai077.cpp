#include<iostream>
#include<math.h>
using namespace std;
void nhap(int& , int& );
int tong(int, int);
int mu(int,int);

int main()
{
	int n, k, s;
	nhap(n, k);
	s = tong(n, k);
	cout << "s = " << s;
	return 0;
}

void nhap(int& n, int& k)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap k = ";
	cin >> k;
}

int mu(int k,int x)
{
	int m = 1;
	for (int i = 1; i <= k; i++)
		m = m * x;
	return m;
}

int tong(int n, int k)
{
	float s = 0;
	for (int i = 1; i <= n; i++)
	{
		s = s + mu(k,i);
	}
	return s;
}