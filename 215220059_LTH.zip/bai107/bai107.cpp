#include<iostream>
#include<math.h>
using namespace std;
float tong(int, int);
void nhap(int&, int&);

int main()
{
	float s;
	int n, x;
	nhap(n, x);
	s = tong(n, x);
	cout << "cos = " << s;
	return 0;
}

float tong(int n, int x)
{
	float e = 1, s = 1, a = 1, b = 1, dau =- 1;
	for (int i = 1; e >= pow(10, -6); i=i+2)
	{
		b = b * x * x;
		a = a * i * (i - 1);
		e = (float)b / a;
		s = s + dau * e;
		dau = -dau;
	}
	return s;
}

void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}