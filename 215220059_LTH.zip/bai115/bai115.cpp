#include<iostream>
#include<math.h>
using namespace std;
int sohang(int);

int main()
{
	int n, a;
	cout << "nhap n = "; cin >> n;
	a = sohang(n);
	cout << "a" << n << " = " << a;
	return 0;
}

int sohang(int n)
{
	int at = 3, att = -1;
	for (int i = 2; i <= n; i++)
	{
		int a = 5 * at + 6 * att;
		att = at;
		at = a;
	}
	return at;
}