#include<iostream>
using namespace std;
void nhap(float&, float&);
float tich(float, float);

int main()
{
	float x, n, t;
	nhap(n,x);
	t = tich(n,x);
	cout << "gia tri x" << n << " bang: " << t;
	return 0;
}

void nhap(float& n, float& x)
{
	cout << "nhap n: ";
	cin >> n;
	cout << "nhap x: ";
	cin >> x;
}

float tich(float n, float x )
{
	float t = 1;
	for (int i = 1; i <= n; i++)
		t = t * x;
	return t;
}