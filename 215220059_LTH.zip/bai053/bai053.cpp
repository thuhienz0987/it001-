#include<iostream>
using namespace std;
void dem(int&);

int main()
{
	int n, s;
	cout << "nhap n: ";
	cin >> n;
	cout << "xac uoc so le la ";
	dem(n);
	return 0;
}

void dem(int& n)
{
	int dem = 0;
	for (int i = 1; i <= n; i=i+2)
	{
		if (n % i == 0) cout << i;
	}
}
