#include<iostream>
using namespace std;
int tich(int);

int main()
{
	int n, s;
	cout << "nhap n: ";
	cin >> n;
	s = tich(n);
	cout << "tich cac uoc bang " << s;
	return 0;
}

int tich(int n)
{
	int s = 1;
	for (int i = 1; i <= n; i++)
	{
		if (n % i == 0) s = s*i;
	}
	return s;
}
