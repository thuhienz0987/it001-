#include<iostream>
using namespace std;
int tong(int);

int main()
{
	int n, s;
	cout << "nhap n: ";
	cin >> n;
	s = tong(n);
	cout << " s = " << s;
	return 0;
}

int tong(int n)
{
	int s = 0;
	for (int i = 1; i <= n; i++)
		s = s + i * (i + 1) * (i + 2);
	return s;
}