#include<iostream>
using namespace std;
int tich(int&);
int main() {
	int n, T;
	cout << "nhap n: ";
	cin >> n;
	T = tich(n);
	cout << "tich bang t= " << T;
	return 0;
}
int tich(int& n)
{
	int t = 1;
	for (int i = 1; i <= n; i++)
	{
		t = t * i;
	}
	return t;
}