#include<iostream>
using namespace std;
float chuvi(float);
int main() 
{
	int r;
	cout << "Nhap ban kinh hinh tron r =  ";
	cin >> r;
	cout << "Chu vi hinh tron ban kinh " << r << " la: " << chuvi(r);
	return 0;
}

float chuvi(float r)
{
	float C = 2 * 3.14 * r;
	return C;
}