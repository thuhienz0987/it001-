#include<iostream>
using namespace std;
int daonguoc(int);

int main()
{
	int n, a;
	cout << "nhap n = "; cin >> n;
	a = daonguoc(n);
	cout << "chu so dao nguoc " << n << " la: " << a;
	return 0;
}

int daonguoc(int n)
{
	int a,b=0;
	for (int c = n; c != 0; c = c / 10)
	{
		a = c % 10;
		b = b * 10 + a;
	}
	return b;
}