#include<iostream>
using namespace std;
int min(int);
int main() {
	int n, nhonhat;
	cout << "nhap n = ";
	cin >> n;
	nhonhat = min(n);
	cout << "t = " << nhonhat;
	return 0;
}

int min(int n)
{
	int min = 9;
	while (n != 0)
	{
		int i = n % 10;
		if ( min>i) min = i;
		n = n / 10;
	}
	return min;
}