#include<iostream>
#include<math.h>
using namespace std;
void nhap(int& n, int& x);
float tong(int, int);


int main()
{
	int n, x;
	float s;
	nhap(n, x);
	s = tong(n, x);
	cout << "s=" << s;
	return 0;
}

void nhap(int& n, int& x)
{
	cout << "nhap n = ";
	cin >> n;
	cout << "nhap x = ";
	cin >> x;
}

float tong(int n, int x)
{
	int a = 1, dau = 1;
	float s = -1;
	for (int i = 2; i <= 2 * n; i = i + 2)
	{
		a = a * (i - 1) * i;
		s = s + dau * (float)pow(x, i) / a;
		dau = -dau;
	}
	return s;
}
