#include<iostream>
using namespace std;
int tich(int);
int main() {
	int n, t;
	cout << "nhap n = ";
	cin >> n;
	t = tich(n);
	cout << "t = " << t;
	return 0;
}

int tich(int n)
{
	int t = 1;
	while (n != 0)
	{
		int i = n % 10;
		if (i % 2 == 1) t = t * i;
		n = n / 10;
	}
	return t;
}