#include<iostream>
using namespace std;
void nhap(int&, int&);
int max(int,int);

int main()
{
	int lonnhat,a,b;
	nhap(a, b);
	lonnhat = max(a, b);
	cout << "max = " << lonnhat;
	return 0;
}

void nhap(int& a, int& b)
{
	cout << " nhap a = "; cin >> a;
	cout << " nhap b = "; cin >> b;
}

int max(int a,int b)
{
	int max = 0;
	if (a < b)  max = b;
	else max = a;
	return max;
}