#include<iostream>
using namespace std;
float doF(float);
int main() 
{
	float C;
	cout << "Nhap do C: ";
	cin >> C;
	cout << "Do F la: " << doF(	C);
	return 0;
}

float doF(float c)
{
	float F =(float) 9 / 5 * c + 32;
	return F;
}