#include<iostream>
#include<math.h>
using namespace std;
float tich(int);

int main() 
{
	int n;
	float t;
	cout << "nhap n: ";
	cin >> n;
	t = tich(n);
	cout << " s = " << t;
	return 0;
}

float tich(int n)
{
	float t = 1;
	for (int i = 1;i <= n; i++)
		t = t * (1 + (float) 1 / pow(i, 2));
	return t;

}