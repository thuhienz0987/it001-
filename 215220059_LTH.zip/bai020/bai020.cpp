#include<iostream>
using namespace std;
float tich(float);
int main()
{
	float x, x14;
	cout << "Nhap x= ";
	cin >> x;
	x14 = tich(x);
	cout << "gia tri x14 la: " << x14;
	return 0;
}

float tich(float x)
{
	float x2 = x * x;
	float x3 = x * x2;
	float x6 = x3 * x3;
	float x12 = x6 * x6;
	float x14 = x12 * x2;
	return x14;
}