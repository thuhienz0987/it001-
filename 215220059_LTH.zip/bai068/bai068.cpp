#include<iostream>
using namespace std;
int giaithua(int);
int tong(int);

int main() 
{
	int n, s;
	cout << "nhap n = ";
	cin >> n;
	s = tong(n);
	cout << "s=" << s;
	return 0;
}

int giaithua(int n)
{
	int g = 1;
	for (int i = 1; i <= n; i++)
		g = g * i;
	return g;
}

int tong(int n)
{
	int s = 0;
	for (int i = 1; i <= n; i++)
		s = s + giaithua(i);
	return s;
}