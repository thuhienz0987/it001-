#include<iostream>
using namespace std;
int tim(int);

int main() 
{
	int n, k = 0;
	cout << "nhap n = "; cin >> n;
	k = tim(n);
	cout << "k = " << k;
	return 0;
}

int tim(int n)
{
	int k = 0;
	for (int h = n; h > 2; h = h / 2)
	{
		k++;
	}
	return k;
}