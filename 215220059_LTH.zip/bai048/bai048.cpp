#include<iostream>
using namespace std;
void nhap(int&, int&);
int tich(int, int);

int main()
{
	int n, x, s;
	nhap(x,n);
	s = tich(x, n);
	cout << " s = " << s;
	return 0;
}

void nhap(int& x, int& n)
{
	cout << "nhap x: ";
	cin >> x;
	cout << "nhap n: ";
	cin >> n;
}

int tich(int x, int n)
{
	float s = 1;
	for (int i = 0; i <= n; i++)
		s = s * (i + x);
	return s;
}