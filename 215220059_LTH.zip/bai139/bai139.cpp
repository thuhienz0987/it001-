#include<iostream>
using namespace std;
void nhap(float&, float&);
void ptbac1(float, float);

int main()
{
	float a, b;
	nhap(a, b);
	ptbac1(a, b);
	return 0;
}

void nhap(float& a, float& b)
{
	cout << "nhap a va b :\n";
	cout << "a = "; cin >> a;
	cout << "b = "; cin >> b;
}

void ptbac1(float a, float b)
{
	if (a == 0) {
		if (b == 0) cout << "phuong trinh vo so nghiem";
		else  cout << "phuong trinh vo nghiem";
	}
	else {
		float x = (float)-b / a;
		cout << "x = " << x;
	}
}