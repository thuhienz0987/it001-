#include<iostream>
using namespace std;
float tich(float);

int main() 
{
	float x,x6;
	cout << "Nhap x= ";
	cin >> x;
	x6 = tich(x);
	cout << "gia tri x6 la: " << x6;
	return 0;
}

float tich(float x)
{
	float x2 = x * x;
	float x4 = x2 * x2;
	float x6 = x4 * x2;
	return x6;
}