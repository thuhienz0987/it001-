#include<iostream>
using namespace std;
float tich(float);

int main()
{
	float x, x7;
	cout << "Nhap x= ";
	cin >> x;
	x7 = tich(x);
	cout << "gia tri x7 la: " << x7;
	return 0;
}

float tich(float x)
{
	float x2 = x * x;
	float x4 = x2 * x2;
	float x6 = x4 * x2;
	float x7 = x6 * x;
	return x7;
}