#include<iostream>
#include<math.h>
using namespace std;
float can(int);
int giaithua(int );

int main() 
{
	int   n;
	float s;
	cout << "nhap n = "; cin >> n;
	s = can(n);
	cout << "s = " << s;
	return 0;
}

int giaithua(int n)
{
	int g = 1;
	for (int i = 1; i <= n; i++)
		g = g * i;
	return g;
}

float can(int n)
{
	float s = 0;
	for (int i = 1; i <= n; i++)
		s = sqrt(giaithua(i) + s);
	return s;
}