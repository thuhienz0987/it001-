#include<iostream>
using namespace std;
void nhap(int&, int&);
void lietke(int, int);

int main()

{
	int x,y;
	nhap(x, y);
	lietke(x, y);
	return 0;
}


void nhap(int& x, int& y)
{
	cout << "nhap x va y : \n";
	cout << "x = "; cin >> x;
	cout << "y = "; cin >> y;
}

void lietke(int x, int y)
{
	for (int i = x; i <= y; i++)
	{
		if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
			cout << i << " ";
	}
}