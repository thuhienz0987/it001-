#include<iostream>
using namespace std;
float tich(float);

int main()
{
	float x, x11;
	cout << "Nhap x= ";
	cin >> x;
	x11 = tich(x);
	cout << "gia tri x11 la: " << x11;
	return 0;
}

float tich(float x)
{
	float x2 = x * x;
	float x3 = x2 * x;
	float x6 = x3 * x3;
	float x12 = x6 * x6;
	float x11 = x12 / x;
	return x11;

}