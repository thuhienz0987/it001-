#include<iostream>
#include<math.h>
using namespace std;
void nhap(float&, float&);
float dientich(float, float);

int main()
{
	float n, r, s;
	nhap(n, r);
	s= dientich(n, r);
	cout << "dien tich da giac deu la: " << s;
	return 0;
}

void nhap(float& n, float& r)
{
	cout << "Nhap so canh cua da giac n= ";
	cin >> n;
	cout << "Nhap ban kinh duong tron r= ";
	cin >> r;
}

float dientich(float n, float r)
{
	float s = 2 * 3.14 * r * r * sin(2*3.14 / n);
	return s;
}
