#include<iostream>
using namespace std;
int dv(int);
int main()
{
	int n,donvi;
	cout << "Nhap so nguyen duong n: ";
	cin >> n;
	donvi = dv(n);
	cout << "chu so hang don vi so nguyen duong n la: " << donvi;

	return 0;
}

int dv(int n)
{
	int dv = n % 10;
	return dv;
}