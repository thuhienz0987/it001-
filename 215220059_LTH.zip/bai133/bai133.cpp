#include<iostream>
using namespace std;
void nhap(int&, int&, int&);
void dieukien(int, int, int);

int main()
{
	int x, y, z;
	nhap(x, y, z);
	dieukien(x, y, z);
	return 0;
}

void nhap(int& x, int& y, int& z)
{
	cout << " nhap x = "; cin >> x;
	cout << " nhap y = "; cin >> y;
	cout << "nhap z = "; cin >> z;
}

void dieukien(int x, int y, int z)
{
	if (x * x + y * y == z * z || z * z + y * y == x * x || x * x + z * z == y * y) 
	{
		if (x == z || y == z || y == x) cout << "tam giac vuong can";
		else cout << "tam giac vuong";
	}
	else
	{
		if (x == y && y == z & z == x) cout << "tam giac deu";
		else
		{
			if (x == y || y == z || z == x) cout << "tam giac can";
			else cout << "tam giac thuong";
		}
	}
}