#include<iostream>
using namespace std;
void nhap(float&, float&, float&, float&, float&, float&);
float khoangcach(float, float, float, float);
float dientich(float&, float&, float&);

int main()
{
	float x1, x2, x3, y1, y2, y3, S, a, b, c;
	nhap(x1, y1, x2, y2, x3, y3);
	a = khoangcach(x1, y1, x2, y2);
	b = khoangcach(x3, y3, x2, y2);
	c = khoangcach(x1, y1, x3, y3);
	S = dientich(a, b, c);
	cout << "Dien tich tam giac ABC la: " << S;
	return 0;
}

void nhap(float& x1, float& y1, float& x2, float& y2, float& x3, float& y3)
{
	cout << "Toa do diem A la: \n";
	cout << "x1= ";
	cin >> x1;
	cout << "y1= ";
	cin >> y1;
	cout << "Toa do diem B la: \n";
	cout << "x2= ";
	cin >> x2;
	cout << "y2= ";
	cin >> y2;
	cout << "Toa do diem C la: \n";
	cout << "x3= ";
	cin >> x3;
	cout << "y3= ";
	cin >> y3;
}

float khoangcach(float x1, float y1, float x2, float y2)
{
	float a = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
	return a;
}

float dientich(float& a, float& b, float& c)
{
	float p = (float)(a + b + c) / 2;
	float S = (float)sqrt(p * (p - a) * (p - b) * (p - c));
	return S;
}

