#include<iostream>
#include<math.h>
using namespace std;
int tong(int);
int giaithua(int);

int main()
{
	int n, k, s;
	cout << "nhap n = "; cin >> n;
	s = tong(n);
	cout << "s = " << s;
	return 0;
}

int giaithua(int n)
{
	int g = 1;
	for (int i = 1; i <= n; i++)
		g = g * i;
	return g;
}


int tong(int n)
{
	float s = 0;
	for (int i = 1; i <= n; i++)
	{
		s = s + i * giaithua(i);
	}
	return s;
}