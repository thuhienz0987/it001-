#include<iostream>
using namespace std;
void nhap(int&, int&);
int boichung(int, int);

int main()
{
	int min, a, b;
	nhap(a, b);
	min = boichung(a, b);
	cout << "boi chung nho nhat la: " << min;
	return 0;
}

void nhap(int& a, int& b)
{
	cout << " nhap a = "; cin >> a;
	cout << " nhap b = "; cin >> b;
}

int boichung(int a, int b)
{
	int x = a, y = b,bc;
	while (x != y)
	{
		if (x < y) y = y - x;
		else x = x - y;
	}
	bc = (a * b) / x;
	return bc;
}