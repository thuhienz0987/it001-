#include<iostream>
using namespace std;
void nhap(int&, int&, int&);
void dieukien(int, int, int);

int main()
{
	int x, y, z;
	nhap(x, y, z);
	dieukien(x, y, z);
	return 0;
}

void nhap(int& x, int& y, int& z)
{
	cout << " nhap x = "; cin >> x;
	cout << " nhap y = "; cin >> y;
	cout << "nhap z = "; cin >> z;
}

void dieukien(int x, int y, int z)
{
	if (x <= y && y <= z)cout << "dung";
	else cout << "sai";
}