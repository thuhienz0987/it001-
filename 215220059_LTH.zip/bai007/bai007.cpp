#include<iostream>
using namespace std;
float doC(float);
int main() 
{
	float F;
	cout << "Nhap do F: ";
	cin >> F;
	cout << "Do C la: " << doC(F);
	return 0;
}

float doC(float F)
{
	float C = (float)5 / 9 * F - 32;
	return C;
}