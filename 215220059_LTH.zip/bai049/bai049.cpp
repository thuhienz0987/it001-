#include<iostream>
using namespace std;
void uoc(int& );

int main()
{
	int n;
	cout << "nhap n: ";
	cin >> n;
	uoc(n);
	return 0;
}

void uoc(int& n)
{
	for (int i = 1; i <= n;i++)
	{
		if (n % i == 0) cout << i << " ";
	}
}
