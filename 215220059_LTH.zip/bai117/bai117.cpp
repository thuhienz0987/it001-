#include<iostream>
#include<math.h>
using namespace std;
int sohang(int);

int main()
{
	int n, a;
	cout << "nhap n = "; cin >> n;
	a = sohang(n);
	cout << "a" << n << " = " << a;
	return 0;
}

int sohang(int n)
{
	int at = 3, att = -1,h=2;
	for (int i = 2; i <= n; i++)
	{
		h = h * 2;
		int a = 5 * h + 5 * at - att;
		att = at;
		at = a;
	}
	return at;
}