#include<iostream>
using namespace std;
int ht(int);
int main() 
{
	int n,hangtram;
	cout << "Nhap so nguyen duong n: ";
	cin >> n;
	hangtram = ht(n);
	cout << "chu so hang tram cua so nguyen duong n la: " << hangtram;
	return 0;
}

int ht(int n)
{
	int ht = (n / 100) % 10;
	return ht;
}