#include<iostream>
#include<math.h>
using namespace std;
float tong(int);

int main()
{
	float s;
	int n;
	cout << "nhap n = "; cin >> n;
	s = tong(n);
	cout << "pi = " << s;
	return 0;
}

float tong(int n)
{
	float e = 1, s = 0, dau = 1;
	for (int i = 0; e >= pow(10, -6); i++)
	{
		e = (float)4 / (2 * i + 1);
		s = s + dau * e;
		dau = -dau;
	}
	return s;
}