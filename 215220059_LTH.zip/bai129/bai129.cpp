#include<iostream>
using namespace std;
void nhap(int&, int&,int& c);
void tangdan(int, int,int);

int main()
{
	int  a, b,c;
	nhap(a, b, c);
	tangdan(a, b, c);
	return 0;
}

void nhap(int& a, int& b,int& c)
{
	cout << " nhap a = "; cin >> a;
	cout << " nhap b = "; cin >> b;
	cout << "nhap c = "; cin >> c;
}

void tangdan(int a, int b,int c)
{
	int temp;
	 if (a > b)
	{
		 temp = a;
		 a = b;
		 b = temp;
	}
	 if (b > c)
	 {
		 temp = b;
		 b = c;
		 c = temp;
		 if (a > b) 
		 {
			 temp = a;
			 a = b;
			 b = temp;
		 }
	 }
	 cout << a << " " << b << " " << c;
}