#include<iostream>
using namespace std;
int kt(int&);

int main()
{
	int n;
	cout << "nhap n = "; cin >> n;
	if (kt(n) == 0) cout << "khong co dang 2^m";
	else cout << "co dang 2^m";
	return 0;
}

int kt(int& n)
{
	int flag = 1;
	while (n > 1)
	{
		if (n % 3 != 0) flag = 0;
		n = n / 3;
	}
	return flag;
}