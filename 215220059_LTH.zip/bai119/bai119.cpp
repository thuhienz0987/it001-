#include<iostream>
#include<math.h>
using namespace std;
float sohang(int);

int main()
{
	int n;
	float a;
	cout << "nhap n = "; cin >> n;
	a = sohang(n);
	cout << "a" << n << " = " << a;
	return 0;
}

float sohang(int n)
{
	float at = 2;
	for (int i = 2; i <= n; i++)
	{
		float a = (at * at + 2) / (2 * at);
		at = a;
	}
	return at;
}