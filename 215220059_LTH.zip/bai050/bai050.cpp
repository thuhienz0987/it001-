#include<iostream>
using namespace std;
int tong(int);

int main()
{
	int n,s;
	cout << "nhap n: ";
	cin >> n;
	s = tong(n);
	cout << "tong cac uoc bang " << s;
	return 0;
}

int tong(int n)
{
	int s = 0;
	for (int i = 1; i <= n; i++)
	{
		if (n % i == 0) s=s+i;
	}
	return s;
}
