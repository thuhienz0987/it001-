#include<iostream>
using namespace std;
float tich(float);
int main() 
{
	float x,x12;
	cout << "Nhap x= ";
	cin >> x;
	x12 = tich(x);
	cout << "gia tri x12 la: " << x12;
	return 0;
}

float tich(float x)
{
	float x2 = x * x;
	float x3 = x * x2;
	float x6 = x3 * x3;
	float x12 = x6 * x6;
	return x12;
}