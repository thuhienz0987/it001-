#include<iostream>
using namespace std;
void dieukien(int);

int main()

{
	int n;
	cout << "nhap nam n = "; cin >> n;
	dieukien(n);
	return 0;
}

void dieukien(int n)
{
	bool dk1, dk2;
	dk1 = n % 4 == 0 && n % 100 != 0;
	dk2 = n % 400 == 0;
	if (dk1 || dk2 == true) cout << "nam nhuan";
	else cout << "nam khong nhuan";
}