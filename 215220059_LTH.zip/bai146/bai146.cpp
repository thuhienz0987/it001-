#include<iostream>
using namespace std;
int doixung(int);

int main() {
	int n;
	cout << "nhap n = "; cin >> n;
	if (doixung(n)==n) cout << n << " la so doi xung";
	else cout << n << " khong la so doi xung";
	return 0;

}

int doixung(int n)
{
	int b, dn = 0;
	for (int a = n; a != 0; a = a / 10)
	{
		b = a % 10;
		dn = dn * 10 + b;
	}
	return dn;
}