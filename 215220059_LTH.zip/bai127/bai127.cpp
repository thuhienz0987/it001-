#include<iostream>
using namespace std;
void nhap(int&, int&);
int min(int, int);

int main()
{
	int nhonhat, a, b;
	nhap(a, b);
	nhonhat = min(a, b);
	cout << "min = " << nhonhat;
	return 0;
}

void nhap(int& a, int& b)
{
	cout << " nhap a = "; cin >> a;
	cout << " nhap b = "; cin >> b;
}

int min(int a, int b)
{
	int min = 0;
	if (a > b)  min = b;
	else min = a;
	return min;
}