#include<iostream>
using namespace std;
float tong(int);

int main()
{
	int n;
	float s;
	cout << "nhap n = "; cin >> n;
	s = tong(n);
	cout << "s = " << s;
	return 0;
}

float tong(int n)
{
	int a = 0,dau=1;
	float s = 0;
	for (int i = 1; i <= n; i++)
	{
		a = a + i;
		s = s + dau*(float)1 / a;
		dau = -dau;

	}
	return s;
}