#include<iostream>
using namespace std;
int tich(int);
int main() {
	int n, t;
	cout << "nhap n = ";
	cin >> n;
	t = tich(n);
	cout << "t = " << t;
	return 0;
}

int tich(int n)
{
	int t = 1;
	while (n != 0)
	{
		int dv = n % 10;
		t = t * dv;
		n = n / 10;
	}
	return t;
}