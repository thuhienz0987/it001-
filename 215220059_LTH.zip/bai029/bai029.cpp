#include<iostream>
using namespace std;
float tong(int n);

int main()
{
	int n;
	float kq;
	cout << "nhap n = ";
	cin >> n;
	kq = tong(n);
	cout << "tong bang " << kq;

	return 0;
}

float tong(int n)
{
	float s = 0;
	for (int i = 1; i <= n; i++)
	{
		s = s + (float)1 / i;
	}
	return s;
}