#include<iostream>
#include<math.h>
using namespace std;
float tong(int);

int main()
{
	int n;
	float  s;
	cout << "nhap n: ";
	cin >> n;
	s = tong(n);
	cout << " s = " << s;
	return 0;
}

float tong(int n)
{
	float s = 0;
	for (int i = 1; i <= n; i++)
		s = s + (float)1 / (sqrt(i) + sqrt(i + 1));
	return s;
}