#include<iostream>
using namespace std;
int csdautien(int);

int main()
{
	int n, a;
	cout << "nhap n = "; cin >> n;
	a = csdautien(n);
	cout << "chu so dau tien cua so " << n << " la: " << a;
	return 0;
}

int csdautien(int n)
{
	int a;
	for (int b = n; b != 0; b = b / 10)
		a = b % 10;
	return a;
}